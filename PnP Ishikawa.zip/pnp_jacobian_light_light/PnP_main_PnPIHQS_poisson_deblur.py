import torch.nn as nn
import torch
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.transforms import ToPILImage
from tqdm import tqdm
import logging
import os
import sys 
import cv2
from PIL import Image
sys.path.append("..") 


import utils.utils_image as util
from utils import utils_logger

    
from models.network_unet import UNetRes as Net
from utils import utils_deblur as deblur

    


model_path = "./SPC_DRUNet_gray_lownoise.pth"
n_channels = 1



model = Net(in_nc=n_channels+1, out_nc=n_channels, nc=[64, 128, 256, 512], nb=4, act_mode='R', downsample_mode="strideconv", upsample_mode="convtranspose", bias=False)
model.load_state_dict(torch.load(model_path), strict=True)
model.eval()
model = model.cuda()
device = 'gpu'
for k, v in model.named_parameters():
    v.requires_grad = False













class Drunet_running(torch.nn.Module):
    def __init__(self):
        super(Drunet_running, self).__init__()

        self.models = model
        self.models.eval()
    
    def to(self, device):
        
        self.models.to(device)    

    def forward(self, x, sigma):
        x = np.array(x)
        x = torch.tensor(x, dtype=torch.float).unsqueeze(0).unsqueeze(0)
        x = x.to(device)
        sigma = float(sigma)
        sigma_div_255 = torch.FloatTensor([sigma/255.]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)
        x = torch.cat((x, sigma_div_255), dim=1)
        return self.models(x)



def run_model(x, sigma):       
    '''
        x is image in [0, 1]
        simga in [0, 255]
    '''

    sigma_div_255 = 0*x + sigma
    x = torch.cat((x, sigma_div_255), dim=1)

    return model(x)
# # #









def print_line(y, pth, label):
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5, label=label)
    plt.legend(loc="upper right")
    plt.xlabel('iter')
    plt.ylabel(label)
    plt.savefig(pth)
    plt.close()    

# nb: default 25 for BSD68
class PnP_ADMM(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nb=25, act_mode='R'):
        super(PnP_ADMM, self).__init__()
        self.nb = nb

        self.net = Drunet_running()

        self.res = {}
        self.res['psnr'] = [0] * nb
        self.res['ssim'] = [0] * nb
        self.res['image'] = [0]* nb
        self.res['mse'] = [0]*nb

    def IRL1(self, f, u, v, b2, sigma, lamb, sigma2, k=10, eps=1e-5):
        for j in range(k):
            fenzi = lamb * (v-f)/(sigma**2+(v-f)**2)+(v-u-b2)
            fenmu = lamb * (sigma**2-(v-f)**2)/(sigma**2+(v-f)**2)**2+1
            v = v - fenzi / fenmu
            v = torch.clamp(v, min=0, max=255.)



        return v

    def get_psnr_i(self, u, clean, i):
        pre_i = torch.clamp(u / 255., 0., 1.)
        img_E = util.tensor2uint(pre_i)
        img_H = util.tensor2uint(clean)
        psnr = util.calculate_psnr(img_E, img_H, border=0)

        ssim = util.calculate_ssim(img_E, img_H, border=0)
        
        self.res['psnr'][i] = psnr
        self.res['ssim'][i] = ssim

        self.res['image'][i] = ToPILImage()(pre_i[0])
        

    def forward(self, kernel, initial_uv, f, clean, sigma=25.5, lamb=690, sigma2=1.0, denoisor_sigma=25, irl1_iter_num=10, eps=1e-5,ratio = 0.): 

        f *= 255
        u  = f
        v  = f
        w  = f

        b2 = torch.zeros(f.shape, device=f.device)
        oldu = u
        oldv = v
        mu = 0.5
        z = u
        w = u
        x = u
        x_= u
        b = 0*u
        bx = 0*u
        bx_= 0*u
        lamb_ = lamb

        K = kernel
        fft_k = deblur.p2o(K, u.shape[-2:])
        fft_kH = torch.conj(fft_k)
        abs_k = fft_kH * fft_k
        
        rho = 2

        fenmu = lamb*abs_k+1
        fenmu2 = rho*abs_k+1
        a = 0.8
        b = 0.15
        d = denoisor_sigma
        for k in range(self.nb):
            self.get_psnr_i(w, clean, k)
            oldoldv = oldv
            oldu = u
            oldv = v
            oldw = w
            oldz = z

            alpha = 1/( (k+1) **a )
            beta  = 1/( (k+1) **b )


            

            bx = 0*x
            x = torch.real(deblur.ifftn(fft_k*deblur.fftn(v)))
            for iii in range(10):
                tmp = torch.real(deblur.ifftn(fft_k*deblur.fftn(v)))
                input_x = tmp-bx
                x = (input_x-lamb_/rho+((input_x-lamb_/rho)**2+4*lamb_/rho*f)**0.5) / 2
                fenzi2 = u + rho* torch.real(deblur.ifftn(fft_kH*deblur.fftn(x+bx)))
                v = torch.real(deblur.ifftn(deblur.fftn(fenzi2)/fenmu2))
                bx = bx + x - tmp

            model_input = (v) / 255.    
            model_input = model_input.type(torch.cuda.FloatTensor)        
            w=run_model(model_input,d) * 255.


            u_ = (1-beta)*u + beta*w

            bx_ = 0*x_
            x_ = torch.real(deblur.ifftn(fft_k*deblur.fftn(v)))
            for iii in range(10):
                tmp = torch.real(deblur.ifftn(fft_k*deblur.fftn(v)))
                input_x = tmp-bx_
                x_ = (input_x-lamb_/rho+((input_x-lamb_/rho)**2+4*lamb_/rho*f)**0.5) / 2
                fenzi2 = u_ + rho* torch.real(deblur.ifftn(fft_kH*deblur.fftn(x_+bx_)))
                v = torch.real(deblur.ifftn(deblur.fftn(fenzi2)/fenmu2))
                bx_ = bx_ + x_ - tmp

            model_input = (v) / 255.     
            model_input = model_input.type(torch.cuda.FloatTensor)        
            w=run_model(model_input,d) * 255.
            
            u  = (1-beta)*u + beta*w
            


            lamb_ = lamb_ / ratio
            d = d / (ratio)**0.5


            newnew = util.tensor2uint(u/255)
            oldold = util.tensor2uint(oldu/255)

            mse_ = np.mean((newnew-oldold)**2)
            self.res['mse'][k] = mse_
            
            

        return w 

def plot_psnr(denoisor_level, lamb, sigma,ratio):
    device = 'cuda'
    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()

    sigma2 = 1.0


    


    kernel_fp = './kernels/kevin_3.png'
    fp = './BSD68_cut/test022.png'
    
    kernel = util.imread_uint(kernel_fp,1) 
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)
    img_H = util.imread_uint(fp, 1)
    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
    print(img_H.shape)
    initial_uv, img_L, img_H = gen_data(img_H, sigma, kernel)

    print(img_H.shape)
    print(img_L.shape)
    print(initial_uv.shape)


    img_L = img_L.to(device)
    img_H = img_H.to(device)
    kernel = kernel.to(device)




    with torch.no_grad():
        img_L, img_H= img_L.to(device), img_H.to(device)
        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5,ratio)
    savepth = 'images/'
    for j in range(len(model.res['image'])):
        model.res['image'][j].save(savepth + 'result_{}.png'.format(j))

    y = model.res['psnr']

    print(y[-1])
    print(np.max(y))
    x = range(len(y))
    plt.figure()
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5)
    plt.xlabel('iter')
    plt.ylabel('PSNR')
    plt.savefig('PSNR_level{}_lamb{}.png'.format(denoisor_level, lamb))








def gen_data(img_clean_uint8, sigma,kernel):

    img_H = img_clean_uint8
    img_L = img_clean_uint8
    
    fft_k = deblur.p2o(kernel, img_L.shape[-2:])

    temp = fft_k * deblur.fftn(img_L)
    img_L = torch.real(deblur.ifftn(temp))
    np.random.seed(seed=0)
    img_L = np.float32(np.random.poisson(img_L * sigma) / sigma)
    img_L = torch.from_numpy(img_L)
    initial_uv = img_L
    return initial_uv, img_L, img_H





def search_args():
    sigma = 100
    utils_logger.logger_info('poisson', log_path='log/peak_{}/logger.log'.format(sigma))
    logger = logging.getLogger('poisson')
    device = 'cuda'

    logger.info('peak = {}'.format(sigma))

    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()


    dataset_root = './BSD68_cut/'
    

    max_psnr   = -1
    max_level  = -1
    max_lamb   = -1
    max_sigma2 = -1
    max_ssim   = -1

    search_range = {}
    kernel_fp = './kernels/kevin_1.png'
    ratio = 1.025
    ## peak =  100, BSD68_cut, poisson noise removal task. 
    # kernel 1 
    search_range[0.1] = [660,680,700,720,740] # ??.????, 0.????
    # kernel 2
    # search_range[0.1] = [660,680,700,720,740] #  
    # kernel 3
    # search_range[0.1] = [660,680,700,720,740] #  
    # kernel 4
    # search_range[0.1] = [660,680,700,720,740] #  
    # kernel 5
    # search_range[0.1] = [660,680,700,720,740] #   
    # kernel 6
    # search_range[0.1] = [660,680,700,720,740] # 
    # kernel 7
    # search_range[0.1] = [660,680,700,720,740] # 
    # kernel 8
    # search_range[0.1] = [660,680,700,720,740] # 


    ## peak =  50, BSD68_cut, poisson noise removal task. 
    # kernel 1 
    # search_range[0.1] = [430,440,450,460,470] # ??.????, 0.????
    # kernel 2
    # search_range[0.1] = [430,440,450,460,470] #  
    # kernel 3
    # search_range[0.1] = [430,440,450,460,470] #  
    # kernel 4
    # search_range[0.1] = [430,440,450,460,470] #  
    # kernel 5
    # search_range[0.1] = [430,440,450,460,470] #   
    # kernel 6
    # search_range[0.1] = [430,440,450,460,470] # 
    # kernel 7
    # search_range[0.1] = [430,440,450,460,470] # 
    # kernel 8
    # search_range[0.1] = [430,440,450,460,470] # 




    alpha = 0.


    search_level = [0.1]# [5, 10, 15, 20, 25, 30]

    


    psnr_save_root  = 'log/' + 'peak_' + str(sigma) + '/psnr'
    ssim_save_root  = 'log/' + 'peak_' + str(sigma) + '/ssim'
    image_save_root = 'log/' + 'peak_' + str(sigma) + '/image'
    if not os.path.exists(psnr_save_root):
        os.makedirs(psnr_save_root)    
    if not os.path.exists(ssim_save_root):
        os.makedirs(ssim_save_root)   
    if not os.path.exists(image_save_root):
        os.makedirs(image_save_root)

    for denoisor_level in search_level:
        logger.info('========================================')
        logger.info('denoisor_level: {}'.format(denoisor_level))
        logger.info('alpha: {}'.format(alpha))
        logger.info('========================================')
        for sigma2 in [1.]: 

            for lamb in search_range[denoisor_level]:
                logger.info('==================')
                logger.info('lamb: {}'.format(lamb))

                dataset_psnr = None
                dataset_ssim = None
                image_paths = util.get_image_paths(dataset_root)

                image_number = len(image_paths)
                print(image_number)
                for ii in range(0,image_number):
                    fp = image_paths[ii]
                    img_H = util.imread_uint(fp, 1)
                    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
                    kernel = util.imread_uint(kernel_fp,1) 
                    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
                    kernel = kernel / torch.sum(kernel)
                    initial_uv, img_L, img_H = gen_data(img_H, sigma, kernel)
                    img_L = img_L.to(device)
                    img_H = img_H.to(device)
                    kernel = kernel.to(device)

                    with torch.no_grad():
                        img_L, img_H= img_L.to(device), img_H.to(device)
                        model(kernel, initial_uv,img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5, ratio)

                    cur_psnr = np.array(model.res['psnr'])

                    print(np.max(cur_psnr)) 
                    cur_ssim = np.array(model.res['ssim'])
                    if dataset_psnr is None:
                        dataset_psnr = cur_psnr
                        dataset_ssim = cur_ssim
                    else:
                        dataset_psnr += cur_psnr
                        dataset_ssim += cur_ssim

                dataset_psnr /= image_number
                dataset_ssim /= image_number
                print(dataset_psnr.shape)


                cur_avg_psnr = dataset_psnr[-1]
                cur_avg_ssim = dataset_ssim[-1]

                logger.info("PSNR: {:.4f}".format(cur_avg_psnr))
                logger.info("SSIM: {:.4f}".format(cur_avg_ssim))
                psnr_save_pth = psnr_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                ssim_save_pth = ssim_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                print_line(dataset_psnr, psnr_save_pth, "PSNR")
                print_line(dataset_ssim, ssim_save_pth, "SSIM")

                if cur_avg_psnr > max_psnr:
                    max_psnr   = cur_avg_psnr
                    max_level  = denoisor_level
                    max_lamb   = lamb
                    max_ssim   = cur_avg_ssim


    logger.info('========================================')
    logger.info('========================================')
    logger.info('max_psnr: {:4f}'.format(max_psnr))
    logger.info('max_ssim: {:4f}'.format(max_ssim))
    logger.info('level: {}'.format(max_level))
    logger.info('lamb: {}'.format(max_lamb))
    return max_psnr, max_level, max_lamb






# note that sigma is the peak in the poisson noise removal settings.



# test001, BSD68_cut, kernel 1, peak=100, nb=25
# plot_psnr(0.1, 700, 100, 1.025) # 21.80
# peak=50
# plot_psnr(0.1, 450, 50, 1.025) # 21.43

# max_psnr, max_level, max_lamb = search_args()

# test022, BSD68_cut, kernel 3, peak=100
plot_psnr(0.1, 700, 100, 1.025) # 22.41













