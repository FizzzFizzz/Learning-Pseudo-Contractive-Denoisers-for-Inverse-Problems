import torch
import cv2
import os
def _jacobian_vec(y, x, v):
    w = torch.ones_like(x, requires_grad=True)
    t = torch.autograd.grad(y, x, w, create_graph=True)[0]
    return torch.autograd.grad(t, w, v, create_graph=True)[0]

def _jacobian_transpose_vec(y, x, v):
    return torch.autograd.grad(y, x, v, create_graph=True)[0]

class JacobianLoss(torch.nn.Module):
    def __init__(self, dt=0.4, iters=5, inner_iters=10, loss_type='max', eps=1e-8):
        super(JacobianLoss, self).__init__()
        self.dt = dt
        self.iters = iters
        self.inner_iters = inner_iters
        self.loss_type = loss_type
        self.eps = eps

    def forward(self, img1, img2, net):
        # jacobian_SPC: to train a strictly pseudo-contractive denoiser.
        jacobian_norm = self.jacobian_SPC(img1[0:1], img2[0:1], net, interpolation=False, training=True)
        # jacobian_norm = self.jacobian_k0(img1[0:1], img2[0:1], net, interpolation=False, training=True)
        # jacobian_norm = self.jacobian_LMMO(img1[0:1], img2[0:1], net, interpolation=False, training=True)
        
        # jacobian_norm = self.jacobian_spectral_norm_yin(img1[0:1], img2[0:1], net, interpolation=False, training=True)
        
        # jacobian_norm = self.jacobian_save(img1[0:1], img2[0:1], net, interpolation=False, training=False)

        # self.log('train/jacobian_norm_max', jacobian_norm.max(), prog_bar=True)

        if self.loss_type == 'max':
            
            jacobian_loss = torch.maximum(jacobian_norm, torch.ones_like(jacobian_norm) - self.eps)

        elif self.loss_type == 'exp':
            jacobian_loss = self.eps * torch.exp(jacobian_norm - (1 + self.eps))  / self.eps
        else:
            print("jacobian loss not available")

        jacobian_loss = torch.clip(jacobian_loss, 0, 1e3)
        # self.log('train/jacobian_loss_max', jacobian_loss.max(), prog_bar=True)


        return jacobian_loss.mean(), jacobian_norm.detach()


    def jacobian_spectral_norm(self, y_in, x_hat, net, interpolation=True, training=False):
        '''
        Jacobian spectral norm from Pesquet et al; computed with a power iteration method.
        Given a denoiser J, computes the spectral norm of Q = 2J-I where J is the denoising model.

        Inputs:
        :y_in: point where the jacobian is to be computed, typically a noisy image (torch Tensor)
        :x_hat: denoised image (unused if interpolation = False) (torch Tensor)
        :sigma: noise level
        :interpolation: whether to compute the jacobian only at y_in, or somewhere on the segment [x_hat, y_in].
        :training: set to True during training to retain grad appropriately
        Outputs:
        :z.view(-1): the square of the Jacobian spectral norm of (2J-Id)

        Beware: reversed usage compared to the original Pesquet et al code.
        '''

        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        if interpolation:
            eta = torch.rand(y_in.size(0), 1, 1, 1, requires_grad=True).to(y_in.device)
            x = eta * y_in.detach() + (1 - eta) * x_hat.detach()
            x = x.to(y_in.device)
        else:
            x = y_in

        x.requires_grad_()
        x_hat = net(torch.cat((x, noise_map), dim=1))

        y = 2 * x_hat - y_in  # Beware notation : y_in = input, x_hat = output network

        u = torch.randn_like(x)
        u = u / torch.norm(u, p=2)

        z_old = torch.zeros(u.shape[0])

        for it in range(self.iters):

            w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
            v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=training)[0]  # Ju

            v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=True)  # vtJt

            z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(
                u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))

            # if it > 0:
            #     rel_var = torch.norm(z - z_old)
            #     if rel_var < self.eps:
            #         break
            z_old = z.clone()

            u = v / torch.norm(v, p=2)  # Modified



        return z.view(-1)

    




    


    def jacobian_LMMO(self, y_in, x_hat, net, interpolation=True, training=False):

        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        if interpolation:
            eta = torch.rand(y_in.size(0), 1, 1, 1, requires_grad=True).to(y_in.device)
            x = eta * y_in.detach() + (1 - eta) * x_hat.detach()
            x = x.to(y_in.device)
        else:
            x = y_in

        x.requires_grad_()
        x_hat = net(torch.cat((x, noise_map), dim=1))

        y = 2*x_hat- y_in
        u = torch.randn_like(x)
        u = u / torch.norm(u, p=2)

        z_old = torch.zeros(u.shape[0])

        for it in range(self.iters):

            w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
            v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=training)[0]  # Ju

            v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=True)  # vtJt

            z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(
                u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))

            z_old = z.clone()

            u = v / torch.norm(v, p=2)  # Modified


        return z.view(-1)





    # to train a strictly pseudo-contractive denoiser.
    def jacobian_SPC(self, y_in, x_hat, net, interpolation=True, training=False):
    

        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        if interpolation:
            eta = torch.rand(y_in.size(0), 1, 1, 1, requires_grad=True).to(y_in.device)
            x = eta * y_in.detach() + (1 - eta) * x_hat.detach()
            x = x.to(y_in.device)
        else:
            x = y_in

        x.requires_grad_()

        # For a 0.5-strictly pseudo-contractive residual denoiser. Stable, good result.
        # x_hat = y_in - net(torch.cat((x, noise_map), dim=1))
        # y = 0.5*x_hat + 0.5*y_in



        # to train a k-strictly pseudo-contractive denoiser. 
        # If you want to train a pseudo-contractive denoiser (k=1), try letting k\approx 1, for example, k=0.95-0.99
        k = 0.9




        u = torch.randn_like(x)
        u = u / torch.norm(u, p=2)

        z_old = torch.zeros(u.shape[0])

        for it in range(self.iters):

            w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
            v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=training)[0]  # Ju

            v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=True)  # vtJt

            z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(
                u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))

            # if it > 0:
            #     rel_var = torch.norm(z - z_old)
            #     if rel_var < self.eps:
            #         break
            z_old = z.clone()

            u = v / torch.norm(v, p=2)  



        return z.view(-1)
    

    
    def jacobian_spectral_norm_yin(self, y_in, x_hat, net, interpolation=True, training=False):

        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        if interpolation:
            eta = torch.rand(y_in.size(0), 1, 1, 1, requires_grad=True).to(y_in.device)
            x = eta * y_in.detach() + (1 - eta) * x_hat.detach()
            x = x.to(y_in.device)
        else:
            x = y_in

        x.requires_grad_()
        x_hat = net(torch.cat((x, noise_map), dim=1))

        
        y = x_hat - y_in  

        u = torch.randn_like(x)
        u = u / torch.norm(u, p=2)

        z_old = torch.zeros(u.shape[0])

        for it in range(self.iters):

            w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
            v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=training)[0]  # Ju

            v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=True)  # vtJt

            z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(
                u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))

            if it > 0:
                rel_var = torch.norm(z - z_old)
                if rel_var < self.eps:
                    break
            z_old = z.clone()

            u = v / torch.norm(v, p=2)  # Modified

        return z.view(-1)
    




    # for pseudo-contractive denoiser (k=1), but not stable, better use jacobian_SPC.
    def jacobian_spectral_norm_selfajoint(self, y_in, x_hat, net, interpolation=True, training=False):
        
        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        if interpolation:
            eta = torch.rand(y_in.size(0), 1, 1, 1, requires_grad=True).to(y_in.device)
            x = eta * y_in.detach() + (1 - eta) * x_hat.detach()
            x = x.to(y_in.device)
        else:
            x = y_in
        x.requires_grad_()
        x_hat = net(torch.cat((x, noise_map), dim=1))
        y = x_hat  
        q = torch.randn_like(x)
        q /= torch.linalg.norm(q)
        # z0_1 = _jacobian_vec(y, x, q)
        # z0_2 = _jacobian_transpose_vec(y, x, q)
        # z0 = z0_1 + z0_2
        z0 = _jacobian_vec(y,x,q) * 0.5 + _jacobian_transpose_vec(y,x,q) * 0.5
        for _ in range(self.iters):
            # gradient step for solving z
            for _ in range(self.inner_iters):
                z0_old = z0.detach()
                vec_z1   = _jacobian_vec(y, x, z0)
                vec_z2   = _jacobian_transpose_vec(y,x,z0)
                vec_z    = vec_z1 + vec_z2 - 4 * z0

                vec_q1   = _jacobian_vec(y, x, q)
                vec_q2   = _jacobian_transpose_vec(y,x,q)
                vec_q    = vec_q1 + vec_q2
                vec      = vec_z - vec_q

                grad_1     = _jacobian_vec(y, x, vec)
                grad_2     = _jacobian_transpose_vec(y, x, vec)
                grad       = grad_1 + grad_2 - 4 * vec
                z0 = z0 - self.dt * grad


                if torch.linalg.norm(z0_old-z0)/torch.linalg.norm(z0) < 0.05:
                    # print('Yes!!!')
                    break
            q_k = q.clone()
            q = z0 / (torch.linalg.norm(z0))  # Modified
        return (torch.linalg.norm(z0)).view(-1)
    



    def jacobian_save(self, y_in, x_hat, net, interpolation=False, training=False):
        
        (y_in, noise_map) = torch.split(y_in, [y_in.shape[1]-1, 1], dim=1)
        
        x = y_in

        x.requires_grad_()
        x_hat = net(torch.cat((x, noise_map), dim=1))
        y = x_hat  
        q = torch.randn_like(x)
        q = 0 * q # now, q is zero vector.
        # q = q.detach()
        
        if not os.path.exists('wdl_try_SPC'):
            map_ = noise_map.detach()
            print(torch.max(map_))
            os.makedirs('wdl_try_SPC')  
            aa = y_in.detach()
            aa = aa.squeeze()
            aa = aa.squeeze()
            aa = aa.cpu().numpy()
            cv2.imwrite('temp_input.png', aa*255)
            bb = x_hat.detach()
            bb = bb.squeeze()
            bb = bb.squeeze()
            bb = bb.cpu().numpy()
            cv2.imwrite('temp_output.png',bb*255)
            for i in range(64):
                for j in range(64):
                    p = 0*q
                    p[0,0,i,j] = 255
                    temp = _jacobian_vec(y,x,p)
                    
                    # p = temp + 127.5
                    p = temp + 63.75
                    p = p.detach()
                    p = p.squeeze()
                    p = p.squeeze()
                    if torch.max(p)>255:
                        print(torch.max(p))
                    # print(torch.min(p))
                    pp = p.cpu().numpy()
                    
                    cv2.imwrite('wdl_try_SPC/' + '{}_{}.png'.format(i,j), pp)
            print('Done!!!!!!')
                
        print(q.shape)

        z0 = _jacobian_vec(y,x,q)

        return (torch.linalg.norm(z0)).view(-1)
    

























