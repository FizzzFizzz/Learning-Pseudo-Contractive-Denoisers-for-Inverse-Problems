import torch.nn as nn
import torch
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.transforms import ToPILImage
from tqdm import tqdm
import logging
import os
import sys 
import cv2
from PIL import Image
sys.path.append("..") 


import utils.utils_image as util
from utils import utils_logger
from utils import utils_option as option
from utils import utils_deblur as deblur
from utils.utils_dist import get_dist_info, init_dist


    
from models.network_unet import UNetRes as Net


    




model_path = "./SPC_DRUNet_gray_lownoise.pth"
n_channels = 1



model = Net(in_nc=n_channels+1, out_nc=n_channels, nc=[64, 128, 256, 512], nb=4, act_mode='R', downsample_mode="strideconv", upsample_mode="convtranspose", bias=False)
model.load_state_dict(torch.load(model_path), strict=True)
model.eval()
model = model.cuda()
device = 'gpu'
for k, v in model.named_parameters():
    v.requires_grad = False













class Drunet_running(torch.nn.Module):
    def __init__(self):
        super(Drunet_running, self).__init__()

        self.models = model
        self.models.eval()
    
    def to(self, device):
        
        self.models.to(device)    

    def forward(self, x, sigma):
        x = np.array(x)
        x = torch.tensor(x, dtype=torch.float).unsqueeze(0).unsqueeze(0)
        x = x.to(device)
        sigma = float(sigma)
        sigma_div_255 = torch.FloatTensor([sigma/255.]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)
        x = torch.cat((x, sigma_div_255), dim=1)
        return self.models(x)



def run_model(x, sigma):       
    '''
        x is image in [0, 1]
        simga in [0, 255]
    '''
    # print(x.size())
    sigma_div_255 = 0*x + sigma
    x = torch.cat((x, sigma_div_255), dim=1)

    return model(x)
# # #







def print_line(y, pth, label):
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5, label=label)
    plt.legend(loc="upper right")
    plt.xlabel('iter')
    plt.ylabel(label)
    plt.savefig(pth)
    plt.close()    

# nb: default 300.
class PnP_ADMM(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nb=300, act_mode='R'):
        super(PnP_ADMM, self).__init__()
        self.nb = nb

        self.net = Drunet_running()
        # self.net = run_model()

        # only test
        self.res = {}
        self.res['psnr'] = [0] * nb
        self.res['ssim'] = [0] * nb
        self.res['image'] = [0]* nb



    def get_psnr_i(self, u, clean, i):
        pre_i = torch.clamp(u / 255., 0., 1.)
        img_E = util.tensor2uint(pre_i)
        img_H = util.tensor2uint(clean)
        psnr = util.calculate_psnr(img_E, img_H, border=0)
        ssim = util.calculate_ssim(img_E, img_H, border=0)
        self.res['psnr'][i] = psnr
        self.res['ssim'][i] = ssim
        self.res['image'][i] = ToPILImage()(pre_i[0])

    def forward(self, kernel, initial_uv, f, clean, sigma=25.5, lamb=690, sigma2=1.0, denoisor_sigma=25, irl1_iter_num=10, eps=1e-5): 

        f *= 255
        u  = f


        K = kernel
        a = 0.3
        b = 0.15

        # a = 0.2
        # b = 0.15

        fft_k = deblur.p2o(K, u.shape[-2:])
        fft_kH = torch.conj(fft_k)
        abs_k = fft_kH * fft_k

        lamb_ = lamb
        d = denoisor_sigma
        t = u
        for k in range(self.nb):

            self.get_psnr_i(torch.clamp(u, min = -0., max =255.), clean, k)

            alpha = 1/( (k+1) **a )
            beta  = 1/( (k+1) **b)

            temp = abs_k * deblur.fftn(u) - fft_kH * deblur.fftn(f)
            temp = torch.real(deblur.ifftn(temp))

            t = u/255
            t = t.type(torch.cuda.FloatTensor)

            v = (1-beta)*u+beta*( run_model(t,d) * 255-lamb_*( temp ) )
            v = torch.clamp(v, min=0, max=255.)

            temp = abs_k * deblur.fftn(v) - fft_kH * deblur.fftn(f)
            temp = torch.real(deblur.ifftn(temp))

            t = v/255
            t = t.type(torch.cuda.FloatTensor)

            u = (1-alpha)*u + alpha*( run_model(t,d) * 255 - lamb_*(temp))
            u = torch.clamp(u, min=0, max=255.)

        
        return u 

def plot_psnr(denoisor_level, lamb, sigma):
    device = 'cuda'
    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()
    

    sigma2 = 1.0

    fp = "./testsets/set12/04.png"
    kernel_fp = './kernels/kevin_8.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)
    img_H = util.imread_uint(fp, 1)
    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel)
    

    initial_uv = initial_uv.to(device)
    img_L = img_L.to(device)
    img_H = img_H.to(device)
    kernel = kernel.to(device)




    with torch.no_grad():
        img_L, img_H = img_L.to(device), img_H.to(device)
        kernel = kernel.to(device)
        # model(img_L, img_H, sigma, lamb, sigma2, denoisor_level, 10, 1e-5)
        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

    savepth = 'images/'
    for j in range(len(model.res['image'])):
        model.res['image'][j].save(savepth + 'result_{}.png'.format(j))

    y = model.res['psnr']

    print(y[-1])
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5)

    plt.xlabel('iter')
    plt.ylabel('PSNR')

    plt.savefig('PSNR_level{}_lamb{}.png'.format(denoisor_level, lamb))






def gen_data(img_clean_uint8, sigma,kernel):
    img_H = img_clean_uint8
    img_L = img_clean_uint8
    fft_k = deblur.p2o(kernel, img_L.shape[-2:])
    temp = fft_k * deblur.fftn(img_L)
    img_L = torch.abs(deblur.ifftn(temp))
    
    np.random.seed(seed=0)

    noise = np.random.normal(0, 1, img_L.shape)*sigma / 255

    img_L += noise


    initial_uv = img_L
    return initial_uv, img_L, img_H



def search_args():
    sigma = 12.75
    sigma = 17.85
    utils_logger.logger_info('rician', log_path='log/sigma_{}/logger.log'.format(sigma))
    logger = logging.getLogger('rician')
    device = 'cuda'

    

    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()


    dataset_root = './testsets/set12/'

    max_psnr   = -1
    max_level  = -1
    max_lamb   = -1
    max_sigma2 = -1

    search_range = {}
    # kevin's 8 kernels, set12, 12.75 noise. a=0.3, b=0.15
    # kernel 01, 
    # search_range[0.04] = [1.8] # 26.5827, 0.7169
    # kernel 02, 
    # search_range[0.04] = [1.8] # 26.3551, 0.7249
    # kernel 03, 
    # search_range[0.04] = [1.8] # 26.9632, 0.7581
    # kernel 04, 
    # search_range[0.04] = [1.8] # 26.1028, 0.7143
    # kernel 05,
    # search_range[0.04] = [1.8] # 27.8494, 0.7673
    # kernel 06,
    # search_range[0.04] = [1.8] # 27.5416, 0.7526
    # kernel 07,
    # search_range[0.04] = [1.8] # 27.3107, 0.7588
    # kernel 08,
    # search_range[0.04] = [2.0] # 26.5750, 0.7342

    # kevin's 8 kernels, set12, 17.85 noise. a=0.3, b=0.15
    # kernel 01, 
    # search_range[0.04] = [1.3] # 25.6116, 0.6827
    # kernel 02, 
    # search_range[0.04] = [1.3] # 25.4629, 0.6940
    # kernel 03, 
    # search_range[0.04] = [1.2] # 26.1323, 0.7338
    # kernel 04, 
    # search_range[0.04] = [1.3] # 25.1001, 0.6801
    # kernel 05,
    # search_range[0.04] = [1.2] # 26.8314, 0.7399
    # kernel 06,
    # search_range[0.04] = [1.2] # 26.5354, 0.7241
    # kernel 07,
    # search_range[0.04] = [1.2] # 26.1829, 0.7270
    # kernel 08,
    search_range[0.04] = [1.2] # 25.5382, 0.7093

    


    kernel_fp = './kernels/kevin_8.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)


    search_level = [0.04]

    psnr_save_root  = 'log/' + 'sigma_' + str(sigma) + '/psnr'
    ssim_save_root  = 'log/' + 'sigma_' + str(sigma) + '/ssim'
    image_save_root = 'log/' + 'sigma_' + str(sigma) + '/image'
    if not os.path.exists(psnr_save_root):
        os.makedirs(psnr_save_root)    
    if not os.path.exists(ssim_save_root):
        os.makedirs(ssim_save_root)   
    if not os.path.exists(image_save_root):
        os.makedirs(image_save_root)

    logger.info(kernel_fp)
    logger.info('sigma = {}'.format(sigma))

    for denoisor_level in search_level:
        logger.info('========================================')
        logger.info('denoisor_level: {}'.format(denoisor_level))
        logger.info('========================================')
        for sigma2 in [1.]: 
            for lamb in search_range[denoisor_level]:
                logger.info('==================')
                logger.info('lamb: {}'.format(lamb))

                dataset_psnr = None
                dataset_ssim = None
                image_paths = util.get_image_paths(dataset_root)
                image_number = len(image_paths)
                for ii in range(0,image_number):
                    fp = image_paths[ii]
                    kernel = util.imread_uint(kernel_fp,1)
                    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
                    kernel = kernel / torch.sum(kernel)
                    img_H = util.imread_uint(fp, 1)
                    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
                    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel)
                    
                    initial_uv = initial_uv.to(device)
                    img_L = img_L.to(device)
                    img_H = img_H.to(device)
                    kernel = kernel.to(device)

                    with torch.no_grad():
                        img_L, img_H = img_L.to(device), img_H.to(device)
                        kernel = kernel.to(device)
                        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

                    cur_psnr = np.array(model.res['psnr'])
                    print(np.max(cur_psnr))
                    cur_ssim = np.array(model.res['ssim'])
                    if dataset_psnr is None:
                        dataset_psnr = cur_psnr
                        dataset_ssim = cur_ssim
                    else:
                        dataset_psnr += cur_psnr
                        dataset_ssim += cur_ssim

                dataset_psnr /= image_number
                dataset_ssim /= image_number
                print(dataset_psnr.shape)

                cur_avg_psnr = np.max(dataset_psnr)
                cur_avg_ssim = np.max(dataset_ssim)
                logger.info("PSNR: {:.4f}".format(cur_avg_psnr))
                logger.info("SSIM: {:.4f}".format(cur_avg_ssim))
                psnr_save_pth = psnr_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                ssim_save_pth = ssim_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                print_line(dataset_psnr, psnr_save_pth, "PSNR")
                print_line(dataset_ssim, ssim_save_pth, "SSIM")

                if cur_avg_psnr > max_psnr:
                    max_psnr   = cur_avg_psnr
                    max_level  = denoisor_level
                    max_lamb   = lamb



    logger.info('========================================')
    logger.info('========================================')
    logger.info('max_psnr: {}'.format(max_psnr))
    logger.info('level: {}'.format(max_level))
    logger.info('lamb: {}'.format(max_lamb))
    return max_psnr, max_level, max_lamb





# 04.png starfish, with kernel8, sigma = 12.75

plot_psnr(0.04, 1.8 , 12.75) # 25.4860, nb = 150



# 05.png monarch, with kernel4, sigma = 17.85

# plot_psnr(0.04, 1.4 , 17.85) # 24.5834, nb = 150





# max_psnr, max_level, max_lamb = search_args()

