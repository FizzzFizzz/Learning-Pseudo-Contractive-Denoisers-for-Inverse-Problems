import torch.nn as nn
import torch
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.transforms import ToPILImage
from tqdm import tqdm
import logging
import os
import sys 
import cv2
from PIL import Image
sys.path.append("..") 


import utils.utils_image as util
from utils import utils_logger
from utils import utils_option as option
from utils import utils_deblur as deblur
from utils import utils_sisr as sr_old
from utils.utils_dist import get_dist_info, init_dist
import utils_sisr_wdl as sr

    
from models.network_unet import UNetRes as Net


    




model_path = "./SPC_DRUNet_color.pth"
n_channels = 3



model = Net(in_nc=n_channels+1, out_nc=n_channels, nc=[64, 128, 256, 512], nb=4, act_mode='R', downsample_mode="strideconv", upsample_mode="convtranspose", bias=False)
model.load_state_dict(torch.load(model_path), strict=True)
model.eval()
model = model.cuda()
device = 'cuda'
for k, v in model.named_parameters():
    v.requires_grad = False













class Drunet_running(torch.nn.Module):
    def __init__(self):
        super(Drunet_running, self).__init__()

        self.models = model
        self.models.eval()
    
    def to(self, device):
        
        self.models.to(device)    

    def forward(self, x, sigma):
        x = np.array(x)
        x = torch.tensor(x, dtype=torch.float).unsqueeze(0).unsqueeze(0)
        x = x.to(device)
        sigma = float(sigma)

        sigma_div_255 = torch.FloatTensor([sigma/255.]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)
        x = torch.cat((x, sigma_div_255), dim=1)
        return self.models(x)



def run_model(x, sigma):       
    '''
        x is image in [0, 1]
        simga in [0, 255]
    '''

    sigma = float(sigma)
    sigma_div_255 = torch.FloatTensor([sigma]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)

    x = torch.cat((x, sigma_div_255), dim=1)

    return model(x)
# # #







def print_line(y, pth, label):
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5, label=label)
    plt.legend(loc="upper right")
    plt.xlabel('iter')
    plt.ylabel(label)
    plt.savefig(pth)
    plt.close()    

# nb: default 50.
class PnP_ADMM(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nb=51, act_mode='R'):
        super(PnP_ADMM, self).__init__()
        self.nb = nb

        self.net = Drunet_running()

        self.res = {}
        self.res['psnr'] = [0] * nb
        self.res['ssim'] = [0] * nb
        self.res['image'] = [0]* nb



    def get_psnr_i(self, u, clean, i):
        pre_i = torch.clamp(u / 255., 0., 1.)
        img_E = util.tensor2uint(pre_i)
        img_H = util.tensor2uint(clean)
        psnr = util.calculate_psnr(img_E, img_H, border=0)
        ssim = util.calculate_ssim(img_E, img_H, border=0)

        self.res['psnr'][i] = psnr
        self.res['ssim'][i] = ssim

        self.res['image'][i] = ToPILImage()(pre_i[0])

    def forward(self, kernel, initial_uv, f, clean, sigma=25.5, lamb=690, sigma2=1.0, denoisor_sigma=25, irl1_iter_num=10, eps=1e-5,sf=4): 

        f *= 255

        temp = f.squeeze(0)
        temp = temp.squeeze(0)
        temp = temp.unsqueeze(-1)
        temp = temp.cpu().numpy()

        y = np.zeros([1,3,clean.shape[2],clean.shape[3]])
        for iiii in range(3):
            x = np.zeros([temp.shape[1],temp.shape[2]])
            x[:,:] = temp[iiii,:,:,0]
            x = cv2.resize(x, (x.shape[1]*sf, x.shape[0]*sf), interpolation=cv2.INTER_CUBIC)
            x = sr_old.shift_pixel(x, sf)
            y[0,iiii,:,:] = x[:,:]

        y = torch.from_numpy(y)
        u = y.type(torch.cuda.FloatTensor)

        K = kernel
        a = 0.6
        b = 0.1


        m = denoisor_sigma
        M = 0.2
        nn = self.nb
        ratio = (M/m)**(2/(nn-1))

        lamb_ = lamb
        d = M
        t = u
        
        img_L_tensor = f / 255
        k_tensor = K
        FB, FBC, F2B, FBFy = sr.pre_calculate(img_L_tensor, k_tensor, sf)



        for k in range(self.nb):

            self.get_psnr_i(torch.clamp(u, min = -0., max =255.), clean, k)

            alpha = 1/( (k+1) **a )
            beta  = 1/( (k+1) **b )
            tau = 1/lamb_

            x = u / 255
            x = sr.data_solution(x.float(), FB, FBC, F2B, FBFy, tau, sf)
            x = x.type(torch.cuda.FloatTensor) * 255
            t = run_model(x/255,d) * 255
            v = (1-beta)*u+beta*t

            x = v / 255
            x = sr.data_solution(x.float(), FB, FBC, F2B, FBFy, tau, sf)
            x = x.type(torch.cuda.FloatTensor) * 255
            t = run_model(x/255,d) * 255
            u = (1-alpha)*v+alpha*t

            lamb_ = lamb_ / ratio
            d = d / (ratio)**0.5

        return torch.clamp(u, min = -0., max =255.) 

def plot_psnr(denoisor_level, lamb, sigma, sf):
    
    device = 'cuda'
    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()
    
    sigma2 = 1.0
    fp = "./trainsets/CBSD68_cut8/0046.png"
    kernel_fp = './kernels/sisr_kernel.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)
    img_H = util.imread_uint(fp, 3)
    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel, sf)
    

    initial_uv = initial_uv.to(device)
    img_L = img_L.to(device)
    img_H = img_H.to(device)
    kernel = kernel.to(device)




    with torch.no_grad():
        img_L, img_H = img_L.to(device), img_H.to(device)
        kernel = kernel.to(device)

        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5,sf)

    savepth = 'images/'
    for j in range(len(model.res['image'])):
        model.res['image'][j].save(savepth + 'result_{}.png'.format(j))

    y = model.res['psnr']

    print(y[-1])
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5)

    plt.xlabel('iter')
    plt.ylabel('PSNR')

    plt.savefig('PSNR_level{}_lamb{}.png'.format(denoisor_level, lamb))






def gen_data(img_clean_uint8, sigma,kernel, sf):
    img_H = img_clean_uint8
    img_L = img_clean_uint8
    k = kernel.squeeze(0)
    k = k.squeeze(0)
    x = img_H.squeeze(0)
    x = x.squeeze(0)

    out = np.zeros([img_H.shape[0],img_H.shape[1], int(img_H.shape[2] / sf), int(img_H.shape[3] / sf)])

    for i in range(3):
        a = torch.zeros([x.shape[1],x.shape[2],1])
        a[:,:,0] = x[i,:,:]
        b = sr_old.classical_degradation(a,k,sf)
        b = torch.from_numpy(b)
        out[0,i,:,:] = b[:,:,0]

    img_L = torch.from_numpy(out).float()
    np.random.seed(seed=0)
    noise = np.random.normal(0, 1, img_L.shape)*sigma / 255
    img_L += noise

    initial_uv = img_L
    return initial_uv, img_L, img_H






def search_args():
    device = 'cuda'
    

    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()


    dataset_root = './trainsets/CBSD68_cut8/'



    max_psnr   = -1
    max_level  = -1
    max_lamb   = -1
    max_sigma2 = -1

    search_range = {}

    sigma = 0
    sf = 4
    utils_logger.logger_info('rician', log_path='log/sigma_{}/logger.log'.format(sigma))
    logger = logging.getLogger('rician')
    logger.info('sigma = {}'.format(sigma))
    # sisr_kernel, set12, 0.00 noise, sf =2, nb=21
    search_range[0.01] = [1e8] # 30.3774, 0.8822
    # sisr_kernel, set12, 2.55 noise, sf =2, nb=21
    search_range[0.01] = [2000] # 27.0884, 0.7602
    # sisr_kernel, set12, 7.65 noise, sf =2, nb=21
    search_range[0.1] = [250] # 25.9298, 0.7012
    
    # sisr_kernel, set12, 0.00 noise, sf =4, nb=21
    search_range[0.01] = [1e7] # 25.7906, 0.7108
    # sisr_kernel, set12, 2.55 noise, sf =4, nb=21
    # search_range[0.02] = [2000] # 25.4705, 0.6878
    # sisr_kernel, set12, 7.65 noise, sf =4, nb=21
    # search_range[0.1] = [300] # 24.7587, 0.6480

    search_level = [0.01]
    


    kernel_fp = './kernels/sisr_kernel.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)


    

    psnr_save_root  = 'log/' + 'sigma_' + str(sigma) + '/psnr'
    ssim_save_root  = 'log/' + 'sigma_' + str(sigma) + '/ssim'
    image_save_root = 'log/' + 'sigma_' + str(sigma) + '/image'
    if not os.path.exists(psnr_save_root):
        os.makedirs(psnr_save_root)    
    if not os.path.exists(ssim_save_root):
        os.makedirs(ssim_save_root)   
    if not os.path.exists(image_save_root):
        os.makedirs(image_save_root)


    for denoisor_level in search_level:
        logger.info('========================================')
        logger.info('denoisor_level: {}'.format(denoisor_level))
        logger.info('========================================')
        for sigma2 in [1.]: 

            for lamb in search_range[denoisor_level]:
                logger.info('==================')
                logger.info('lamb: {}'.format(lamb))

                dataset_psnr = None
                dataset_ssim = None
                image_paths = util.get_image_paths(dataset_root)
                image_number=12
                image_number = len(image_paths)
                for ii in range(0,image_number):
                    fp = image_paths[ii]

                    kernel = util.imread_uint(kernel_fp,1)
                    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
                    kernel = kernel / torch.sum(kernel)
                    img_H = util.imread_uint(fp, 3)
                    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
                    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel, sf)
                    
                    initial_uv = initial_uv.to(device)
                    img_L = img_L.to(device)
                    img_H = img_H.to(device)
                    kernel = kernel.to(device)

                    with torch.no_grad():
                        img_L, img_H = img_L.to(device), img_H.to(device)
                        kernel = kernel.to(device)
                        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5, sf)

                    cur_psnr = np.array(model.res['psnr'])
                    print(np.max(cur_psnr))
                    cur_ssim = np.array(model.res['ssim'])
                    if dataset_psnr is None:
                        dataset_psnr = cur_psnr
                        dataset_ssim = cur_ssim
                    else:
                        dataset_psnr += cur_psnr
                        dataset_ssim += cur_ssim

                dataset_psnr /= image_number
                dataset_ssim /= image_number
                print(dataset_psnr.shape)

                cur_avg_psnr = np.max(dataset_psnr)
                cur_avg_ssim = np.max(dataset_ssim)
                logger.info("PSNR: {:.4f}".format(cur_avg_psnr))
                logger.info("SSIM: {:.4f}".format(cur_avg_ssim))
                psnr_save_pth = psnr_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                ssim_save_pth = ssim_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                print_line(dataset_psnr, psnr_save_pth, "PSNR")
                print_line(dataset_ssim, ssim_save_pth, "SSIM")

                if cur_avg_psnr > max_psnr:
                    max_psnr   = cur_avg_psnr
                    max_level  = denoisor_level
                    max_lamb   = lamb



    logger.info('========================================')
    logger.info('========================================')
    logger.info('max_psnr: {}'.format(max_psnr))
    logger.info('level: {}'.format(max_level))
    logger.info('lamb: {}'.format(max_lamb))
    return max_psnr, max_level, max_lamb


# PnPI-HQS 0009.png, s=4, sigma=7.65
# plot_psnr(0.1, 200, 7.65, 4)
# plot_psnr(0.02, 2000, 2.55, 4)
# plot_psnr(0.01, 1e7, 0, 4)

# PnPI-HQS 0026.png, s=4, 
# plot_psnr(0.01, 1e7, 0, 4)
# plot_psnr(0.01, 2000, 2.55, 2)

# PnPI-HQS 0000.png, s=4, 
# plot_psnr(0.01, 1e7, 0, 4)
# plot_psnr(0.001, 1e8, 0, 2) # nb=51 !!!

# PnPI-HQS 0046.png, s=4, 
# plot_psnr(0.07, 2000, 2.55, 4) # nb=51 !!!
plot_psnr(0.07, 3000, 2.55, 2) # nb=51 !!!
# max_psnr, max_level, max_lamb = search_args() # default nb=21!!



