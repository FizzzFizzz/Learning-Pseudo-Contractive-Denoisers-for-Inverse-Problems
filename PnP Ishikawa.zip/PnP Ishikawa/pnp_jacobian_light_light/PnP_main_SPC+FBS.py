import torch.nn as nn
import torch
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.transforms import ToPILImage
from tqdm import tqdm
import logging
import os
import sys 
import cv2
from PIL import Image
sys.path.append("..") 


import utils.utils_image as util
from utils import utils_logger

    
from models.network_unet import UNetRes as Net


    




model_path = "./SPC_DRUNet_gray.pth"
n_channels = 1



model = Net(in_nc=n_channels+1, out_nc=n_channels, nc=[64, 128, 256, 512], nb=4, act_mode='R', downsample_mode="strideconv", upsample_mode="convtranspose", bias=False)
model.load_state_dict(torch.load(model_path), strict=True)
model.eval()
model = model.cuda()
device = 'gpu'
for k, v in model.named_parameters():
    v.requires_grad = False













class Drunet_running(torch.nn.Module):
    def __init__(self):
        super(Drunet_running, self).__init__()

        self.models = model
        self.models.eval()
    
    def to(self, device):
        
        self.models.to(device)    

    def forward(self, x, sigma):
        x = np.array(x)
        x = torch.tensor(x, dtype=torch.float).unsqueeze(0).unsqueeze(0)
        x = x.to(device)
        sigma = float(sigma)
        sigma_div_255 = torch.FloatTensor([sigma/255.]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)
        x = torch.cat((x, sigma_div_255), dim=1)
        return self.models(x)



def run_model(x, sigma):       
    '''
        x is image in [0, 1]
        simga in [0, 255]
    '''

    sigma_div_255 = 0*x + sigma
    x = torch.cat((x, sigma_div_255), dim=1)

    return model(x)
# # #

def gaussian(img, kernel_size, sigma):
    gaussian_kernel = np.zeros((kernel_size, kernel_size))

    sum = 0
    for i in range(kernel_size):
        for j in range(kernel_size):
            gaussian_kernel[i][j] = math.exp((-1 / 2) * (np.square(i - (kernel_size - 1) / 2) + np.square(j - (kernel_size - 1) / 2)) / sigma**2) / (2 * math.pi * sigma**2)
            sum = sum + gaussian_kernel[i][j]
    gaussian_kernel = gaussian_kernel / sum

    rows = np.size(img, 0)
    columns = np.size(img, 1)
    for i in range(0, rows - kernel_size + 1):
        for j in range(0, columns - kernel_size + 1):
            img[i][j] = np.sum(np.sum(gaussian_kernel * img[i:i + kernel_size, j:j + kernel_size]))
    return img







def print_line(y, pth, label):
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5, label=label)
    plt.legend(loc="upper right")
    plt.xlabel('iter')
    plt.ylabel(label)
    plt.savefig(pth)
    plt.close()    

# nb: default 50.
class PnP_ADMM(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nb=300, act_mode='R'):
        super(PnP_ADMM, self).__init__()
        self.nb = nb

        self.net = Drunet_running()

        self.res = {}
        self.res['psnr'] = [0] * nb
        self.res['ssim'] = [0] * nb
        self.res['image'] = [0]* nb



    def get_psnr_i(self, u, clean, i):
        pre_i = torch.clamp(u / 255., 0., 1.)
        img_E = util.tensor2uint(pre_i)
        img_H = util.tensor2uint(clean)
        psnr = util.calculate_psnr(img_E, img_H, border=0)

        ssim = util.calculate_ssim(img_E, img_H, border=0)
        self.res['psnr'][i] = psnr
        self.res['ssim'][i] = ssim

        self.res['image'][i] = ToPILImage()(pre_i[0])

    def forward(self, initial_uv, f, clean, sigma=25.5, lamb=690, sigma2=1.0, denoisor_sigma=25, irl1_iter_num=10, eps=1e-5): 

        f *= 255
        u  = initial_uv * 255



        a = 0.8
        b = 0.15

        for k in range(self.nb):


            alpha = 1/( (k+1) **a )
            beta  = 1/( (k+1) **b )
            epss = 1e0 
            t = u - lamb*(1-f/(u+epss))

            t = torch.clamp(t, min = -50., max =305.)
            v = (1-beta)*u+beta*(run_model(t/255,denoisor_sigma) * 255)

            t = v - lamb*(1-f/(v+epss))
            t = torch.clamp(t, min = -0., max =255.)
            u = (1-alpha)*u+alpha*(run_model(t/255,denoisor_sigma) * 255)


            self.get_psnr_i(u, clean, k)
            
            
        
        return u 

def plot_psnr(denoisor_level, lamb, sigma):
    device = 'cuda'
    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()
    

    sigma2 = 1.0

    fp = "./testsets/set12/08.png"

    img_H = util.imread_uint(fp, 1)
    print(img_H.shape)
    initial_uv, img_L, img_H = gen_data(img_H, sigma)


    print(img_H.shape)
    print(img_L.shape)
    print(initial_uv.shape)

    initial_uv = initial_uv.to(device)
    img_L = img_L.to(device)
    img_H = img_H.to(device)




    with torch.no_grad():
        img_L, img_H = img_L.to(device), img_H.to(device)
        model(initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

    savepth = 'images/'
    for j in range(len(model.res['image'])):
        model.res['image'][j].save(savepth + 'result_{}.png'.format(j))

    y = model.res['psnr']

    print(y[-1])
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5)

    plt.xlabel('iter')
    plt.ylabel('PSNR')

    plt.savefig('PSNR_level{}_lamb{}.png'.format(denoisor_level, lamb))






def gen_data(img_clean_uint8, sigma):
    img_H = img_clean_uint8
    img_H = util.uint2single(img_H)
    img_L = np.copy(img_H)

    np.random.seed(seed=0)



    img_L = np.float32(np.random.poisson(img_L * sigma) / sigma)




    img_L = util.single2tensor3(img_L).unsqueeze(0)
    img_H = util.single2tensor3(img_H).unsqueeze(0)
    
    initial_uv = img_L
    return initial_uv, img_L, img_H






def search_args():
    sigma = 20
    utils_logger.logger_info('poissonnoise', log_path='log/sigma_{}/logger.log'.format(sigma))
    logger = logging.getLogger('poissonnoise')
    device = 'cuda'

    logger.info('sigma = {}'.format(sigma))

    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()


    dataset_root = './testsets/set12/'
    

    max_psnr   = -1
    max_level  = -1
    max_lamb   = -1
    max_sigma2 = -1

    search_range = {}
    ## peak = sigma = 20, Set12, poisson noise removal task. max iter = 300
    search_range[0.10] = (60,61,3) # 

    ## peak = sigma = 15, Set12, poisson noise removal task.
    # search_range[0.12] = (68, 74, 2) # 

    ## peak = sigma = 10, Set12, poisson noise removal task.
    # search_range[0.14] = (60, 61, 1) # 

    search_level = [0.10]# [5, 10, 15, 20, 25, 30]

    psnr_save_root  = 'log/' + 'sigma_' + str(sigma) + '/psnr'
    ssim_save_root  = 'log/' + 'sigma_' + str(sigma) + '/ssim'
    image_save_root = 'log/' + 'sigma_' + str(sigma) + '/image'
    if not os.path.exists(psnr_save_root):
        os.makedirs(psnr_save_root)    
    if not os.path.exists(ssim_save_root):
        os.makedirs(ssim_save_root)   
    if not os.path.exists(image_save_root):
        os.makedirs(image_save_root)

    for denoisor_level in search_level:
        logger.info('========================================')
        logger.info('denoisor_level: {}'.format(denoisor_level))
        logger.info('========================================')
        for sigma2 in [1.]: 
            for lamb in range(*search_range[denoisor_level]):
            # for lamb in search_range[denoisor_level]:
                logger.info('==================')
                logger.info('lamb: {}'.format(lamb))

                dataset_psnr = None
                dataset_ssim = None
                image_paths = util.get_image_paths(dataset_root)

                image_number=12
                image_number = len(image_paths)
                for ii in range(0,image_number):

                    fp = image_paths[ii]

                    img_H = util.imread_uint(fp, 1)
                    
                    initial_uv, img_L, img_H = gen_data(img_H, sigma)
                    initial_uv = initial_uv.to(device)
                    img_L = img_L.to(device)
                    img_H = img_H.to(device)

                    with torch.no_grad():
                        model(initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

                    cur_psnr = np.array(model.res['psnr'])

                    print(np.max(cur_psnr))
                    cur_ssim = np.array(model.res['ssim'])
                    if dataset_psnr is None:
                        dataset_psnr = cur_psnr
                        dataset_ssim = cur_ssim
                    else:
                        dataset_psnr += cur_psnr
                        dataset_ssim += cur_ssim

                dataset_psnr /= image_number
                dataset_ssim /= image_number
                print(dataset_psnr.shape)

                cur_avg_psnr = np.max(dataset_psnr)
                cur_avg_ssim = np.max(dataset_ssim)
                logger.info("PSNR: {:.4f}".format(cur_avg_psnr))
                logger.info("SSIM: {:.4f}".format(cur_avg_ssim))
                psnr_save_pth = psnr_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                ssim_save_pth = ssim_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                print_line(dataset_psnr, psnr_save_pth, "PSNR")
                print_line(dataset_ssim, ssim_save_pth, "SSIM")

                if cur_avg_psnr > max_psnr:
                    max_psnr   = cur_avg_psnr
                    max_level  = denoisor_level
                    max_lamb   = lamb



    logger.info('========================================')
    logger.info('========================================')
    logger.info('max_psnr: {}'.format(max_psnr))
    logger.info('level: {}'.format(max_level))
    logger.info('lamb: {}'.format(max_lamb))
    return max_psnr, max_level, max_lamb






# note that sigma is the peak in the poisson noise removal settings.

# PnPI-FBS
# plot_psnr(0.12, 90, 20) # cameraman, peak = 20, psnr = 27.9918
# plot_psnr(0.12, 80, 20) # cameraman, peak = 20, psnr = 27.9310
# plot_psnr(0.10, 60, 20) # cameraman, peak = 20, psnr = 27.9252

# plot_psnr(0.12, 68, 15) # cameraman, peak = 15, psnr = 27.4770

# plot_psnr(0.12, 60, 15) # house, peak = 15, psnr = 30.7414
# plot_psnr(0.12, 70, 15) # cameraman, peak = 15, psnr = 27.4770
max_psnr, max_level, max_lamb = search_args()

