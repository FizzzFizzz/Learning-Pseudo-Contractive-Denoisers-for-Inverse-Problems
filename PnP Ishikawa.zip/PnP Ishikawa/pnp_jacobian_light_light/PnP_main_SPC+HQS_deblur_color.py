import torch.nn as nn
import torch
import math
import numpy as np
import matplotlib.pyplot as plt
from torchvision.transforms import ToPILImage
from tqdm import tqdm
import logging
import os
import sys 
import cv2
from PIL import Image
sys.path.append("..") 


import utils.utils_image as util
from utils import utils_logger
from utils import utils_option as option
from utils import utils_deblur as deblur
from utils.utils_dist import get_dist_info, init_dist


    
from models.network_unet import UNetRes as Net


    




model_path = "./SPC_DRUNet_color.pth"
n_channels = 3



model = Net(in_nc=n_channels+1, out_nc=n_channels, nc=[64, 128, 256, 512], nb=4, act_mode='R', downsample_mode="strideconv", upsample_mode="convtranspose", bias=False)
model.load_state_dict(torch.load(model_path), strict=True)
model.eval()
model = model.cuda()
device = 'cuda'
for k, v in model.named_parameters():
    v.requires_grad = False













class Drunet_running(torch.nn.Module):
    def __init__(self):
        super(Drunet_running, self).__init__()

        self.models = model
        self.models.eval()
    
    def to(self, device):
        
        self.models.to(device)    

    def forward(self, x, sigma):
        x = np.array(x)
        x = torch.tensor(x, dtype=torch.float).unsqueeze(0).unsqueeze(0)
        x = x.to(device)
        sigma = float(sigma)
        sigma_div_255 = torch.FloatTensor([sigma/255.]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)
        x = torch.cat((x, sigma_div_255), dim=1)
        return self.models(x)



def run_model(x, sigma):       
    '''
        x is image in [0, 1]
        simga in [0, 255]
    '''

    sigma = float(sigma)
    sigma_div_255 = torch.FloatTensor([sigma]).repeat(1, 1, x.shape[2], x.shape[3]).to(device)

    x = torch.cat((x, sigma_div_255), dim=1)

    return model(x)
# # #








def print_line(y, pth, label):
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5, label=label)
    plt.legend(loc="upper right")
    plt.xlabel('iter')
    plt.ylabel(label)
    plt.savefig(pth)
    plt.close()    

# nb: default 100.
class PnP_ADMM(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nb=21, act_mode='R'):
        super(PnP_ADMM, self).__init__()
        self.nb = nb

        self.net = Drunet_running()

        self.res = {}
        self.res['psnr'] = [0] * nb
        self.res['ssim'] = [0] * nb
        self.res['image'] = [0]* nb


    def get_psnr_i(self, u, clean, i):
        pre_i = torch.clamp(u / 255., 0., 1.)
        img_E = util.tensor2uint(pre_i)
        img_H = util.tensor2uint(clean)
        psnr = util.calculate_psnr(img_E, img_H, border=0)

        ssim = util.calculate_ssim(img_E, img_H, border=0)
        self.res['psnr'][i] = psnr
        self.res['ssim'][i] = ssim

        self.res['image'][i] = ToPILImage()(pre_i[0])

    def forward(self, kernel, initial_uv, f, clean, sigma=25.5, lamb=690, sigma2=1.0, denoisor_sigma=25, irl1_iter_num=10, eps=1e-5): 
       
        f *= 255
        u  = f

        K = kernel

        # a = 0.8
        # b = 0.15
        a = 0.6
        b = 0.1

        fft_k = deblur.p2o(K, u.shape[-2:])
        fft_kH = torch.conj(fft_k)
        abs_k = fft_kH * fft_k
        lamb_ = lamb
        d = denoisor_sigma
        t = u
        for k in range(self.nb):

            self.get_psnr_i(torch.clamp(u, min = -0., max =255.), clean, k)

            alpha = 1/( (k+1) **a )
            beta  = 1/( (k+1) **b )
            fenmu = lamb_*abs_k+1

            t = t.type(torch.cuda.FloatTensor)

            v = (1-beta)*u+beta*(run_model(t/255,d) * 255)
            fenzi = deblur.fftn(u) + lamb_ * fft_kH*deblur.fftn(f)
            t = torch.real(deblur.ifftn(fenzi/fenmu))


            
            t = t.type(torch.cuda.FloatTensor)
            
            u = (1-alpha)*u+alpha*(run_model(t/255,d) * 255)
            fenzi = deblur.fftn(v) + lamb_ * fft_kH*deblur.fftn(f)
            t = torch.real(deblur.ifftn(fenzi/fenmu))
 
            t = t.type(torch.cuda.FloatTensor)
            
            ratio = 1.1237

            

            lamb_ = lamb_ / ratio
            d = d / (ratio)**0.5

            
            
            
        
        return torch.clamp(u, min = -0., max =255.) 

def plot_psnr(denoisor_level, lamb, sigma):
    device = 'cuda'
    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()
    
    # i = 4
    sigma2 = 1.0

    fp = './trainsets/CBSD68_cut8/0000.png'
    kernel_fp = './pnp_jacobian/kernels/kevin_1.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)
    img_H = util.imread_uint(fp, 3)
    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.
    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel)
    

    initial_uv = initial_uv.to(device)
    img_L = img_L.to(device)
    img_H = img_H.to(device)
    kernel = kernel.to(device)




    with torch.no_grad():
        img_L, img_H = img_L.to(device), img_H.to(device)
        kernel = kernel.to(device)
        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

    savepth = 'images/'
    for j in range(len(model.res['image'])):
        model.res['image'][j].save(savepth + 'result_{}.png'.format(j))

    y = model.res['psnr']

    print(y[-1])
    x = range(len(y))
    plt.plot(x, y, '-', alpha=0.8, linewidth=1.5)

    plt.xlabel('iter')
    plt.ylabel('PSNR')

    plt.savefig('PSNR_level{}_lamb{}.png'.format(denoisor_level, lamb))






def gen_data(img_clean_uint8, sigma,kernel):
    img_H = img_clean_uint8
    img_L = img_clean_uint8
    fft_k = deblur.p2o(kernel, img_L.shape[-2:])
    temp = fft_k * deblur.fftn(img_L)
    img_L = torch.abs(deblur.ifftn(temp))
    
    np.random.seed(seed=0)

    noise = np.random.normal(0, 1, img_L.shape)*sigma / 255

    img_L += noise


    initial_uv = img_L
    return initial_uv, img_L, img_H






def search_args():
    sigma = 12.75
    sigma = 17.85
    utils_logger.logger_info('rician', log_path='log/sigma_{}/logger.log'.format(sigma))
    logger = logging.getLogger('rician')
    device = 'cuda'

    logger.info('sigma = {}'.format(sigma))

    model = PnP_ADMM()
    model.to(device)
    model.net.to(device)
    model.eval()
    model.net.eval()


    dataset_root = './trainsets/CBSD68_cut8/'

    max_psnr   = -1
    max_level  = -1
    max_lamb   = -1
    max_sigma2 = -1

    search_range = {}
    


    # kevin's 8 kernels, CBSD68, 12.75 noise, ratio = 1.057, 50itr
    # kernel 01, 
    # search_range[0.2] = [70] # 27.2971, 0.7599, (38.40, 26.32, 32.03, 0.12, 26)
    # kernel 02, 
    # search_range[0.2] = [70] # 
    # kernel 03, 
    # search_range[0.2] = [70] # 
    # kernel 04, 
    # search_range[0.2] = [70] # 
    # kernel 05,
    # search_range[0.2] = [70] # 
    # kernel 06,
    # search_range[0.2] = [70] # 
    # kernel 07,
    # search_range[0.2] = [70] # 
    # kernel 08,
    # search_range[0.2] = [70] # 

    # kevin's 8 kernels, CBSD68, 12.75 noise, ratio = 1.1487, 20itr
    # kernel 01, 
    # search_range[0.2] = [72] # 27.4512, 0.7619
    # kernel 02, 
    # search_range[0.2] = [72] # 27.2312, 0.7541
    # kernel 03, 
    # search_range[0.2] = [72] # 27.5887, 0.7662
    # kernel 04, 
    # search_range[0.2] = [72] # 26.9972, 0.7431
    # kernel 05,
    # search_range[0.2] = [72] # 28.5799, 0.8042
    # kernel 06,
    # search_range[0.2] = [72] # 28.3969, 0.7991
    # kernel 07,
    # search_range[0.2] = [72] # 27.6671, 0.7722
    # kernel 08,
    # search_range[0.2] = [72] # 27.2508, 0.7568


    # kevin's 8 kernels, CBSD68, 17.85 noise, ratio = 1.1237 20itr

    # kernel 01, 
    search_range[0.2] = [37] # 26.4330, 0.7202; 26.4273, 0.7214
    # kernel 02, 
    search_range[0.2] = [37] # 26.2142, 0.7109; 26.2415, 0.7134
    # kernel 03, 
    search_range[0.2] = [40] # 26.7383, 0.7350; 26.7584, 0.7378
    # kernel 04, 
    search_range[0.2] = [40] # 26.0077, 0.7059; 25.9943, 0.7067
    # kernel 05,
    search_range[0.2] = [37] # 27.5922, 0.7696; 27.6514, 0.7728
    # kernel 06,
    search_range[0.2] = [37] # 27.3468, 0.7610; 27.3631, 0.7630
    # kernel 07,
    search_range[0.2] = [42] # 26.8047, 0.7436; 26.8185, 0.7457
    # kernel 08,
    search_range[0.2] = [40] # 26.3076, 0.7222; 26.3267, 0.7252



    kernel_fp = './kernels/kevin_8.png'
    kernel = util.imread_uint(kernel_fp,1)
    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
    kernel = kernel / torch.sum(kernel)


    search_level = [0.2]

    psnr_save_root  = 'log/' + 'sigma_' + str(sigma) + '/psnr'
    ssim_save_root  = 'log/' + 'sigma_' + str(sigma) + '/ssim'
    image_save_root = 'log/' + 'sigma_' + str(sigma) + '/image'
    if not os.path.exists(psnr_save_root):
        os.makedirs(psnr_save_root)    
    if not os.path.exists(ssim_save_root):
        os.makedirs(ssim_save_root)   
    if not os.path.exists(image_save_root):
        os.makedirs(image_save_root)

    for denoisor_level in search_level:
        logger.info('========================================')
        logger.info('denoisor_level: {}'.format(denoisor_level))
        logger.info('========================================')
        for sigma2 in [1.]: 
            # for lamb in range(*search_range[denoisor_level]):
            for lamb in search_range[denoisor_level]:
                logger.info('==================')
                logger.info('lamb: {}'.format(lamb))

                dataset_psnr = None
                dataset_ssim = None
                image_paths = util.get_image_paths(dataset_root)

                image_number = len(image_paths)

                for ii in range(0,image_number):
                    fp = image_paths[ii]

                    kernel = util.imread_uint(kernel_fp,1)
                    kernel = util.single2tensor3(kernel).unsqueeze(0) / 255.
                    kernel = kernel / torch.sum(kernel)
                    img_H = util.imread_uint(fp, 3)
                    img_H = util.single2tensor3(img_H).unsqueeze(0) /255.

                    initial_uv, img_L, img_H = gen_data(img_H, sigma,kernel)
                    
                    
                    initial_uv = initial_uv.to(device)
                    img_L = img_L.to(device)
                    img_H = img_H.to(device)
                    kernel = kernel.to(device)

                    with torch.no_grad():
                        img_L, img_H = img_L.to(device), img_H.to(device)
                        kernel = kernel.to(device)
                        model(kernel, initial_uv, img_L, img_H, sigma, lamb, sigma2, denoisor_level, 5, 1e-5)

                    cur_psnr = np.array(model.res['psnr'])

                    print(np.max(cur_psnr))
                    cur_ssim = np.array(model.res['ssim'])
                    if dataset_psnr is None:
                        dataset_psnr = cur_psnr
                        dataset_ssim = cur_ssim
                    else:
                        dataset_psnr += cur_psnr
                        dataset_ssim += cur_ssim

                dataset_psnr /= image_number
                dataset_ssim /= image_number
                print(dataset_psnr.shape)

                cur_avg_psnr = np.max(dataset_psnr)
                cur_avg_ssim = np.max(dataset_ssim)
                logger.info("PSNR: {:.4f}".format(cur_avg_psnr))
                logger.info("SSIM: {:.4f}".format(cur_avg_ssim))
                psnr_save_pth = psnr_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                ssim_save_pth = ssim_save_root + '/level' + str(denoisor_level) + '_lamb' + str(lamb) + '_psnr' + str(cur_avg_psnr)[:7] + '.png'
                print_line(dataset_psnr, psnr_save_pth, "PSNR")
                print_line(dataset_ssim, ssim_save_pth, "SSIM")

                if cur_avg_psnr > max_psnr:
                    max_psnr   = cur_avg_psnr
                    max_level  = denoisor_level
                    max_lamb   = lamb



    logger.info('========================================')
    logger.info('========================================')
    logger.info('max_psnr: {}'.format(max_psnr))
    logger.info('level: {}'.format(max_level))
    logger.info('lamb: {}'.format(max_lamb))
    return max_psnr, max_level, max_lamb








# max_psnr, max_level, max_lamb = search_args()
# PnPI-HQS 0026.png, kernel 6.
# plot_psnr(0.2, 37, 17.85) 

# PnPI-HQS 0037.png, kernel 2.
plot_psnr(0.2, 72, 12.75) 


